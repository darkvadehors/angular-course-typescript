export class Person {

    constructor() {
        console.log('it works');
    }

}