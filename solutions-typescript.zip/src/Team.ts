import {Person} from './Person';

export class Team {

  constructor(public persons: Person[] = []) {
  }

  /**
  addPerson(person: Person) {}
  deletePersonById(id: number) {}
  */
  
}